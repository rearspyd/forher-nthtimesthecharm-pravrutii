import { useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import dayjs from "dayjs";
import { Download } from "lucide-react";
import { API, api } from "@/lib/api";
import { Button } from "@/components/ui/button";

export default function SharedReport() {
  const { token } = useParams();
  const q = useQuery({ queryKey: ["share", token], queryFn: () => api.get(`/share/${token}`).then((r) => r.data), retry: false });
  const s = q.data;

  return (
    <main className="mx-auto max-w-3xl px-6 py-10 space-y-6">
      <header>
        <p className="fh-eyebrow">ForHer · shared clinician summary</p>
        <h1 className="mt-1 text-4xl font-semibold tracking-tight">Cycle summary</h1>
        <p className="mt-2 text-sm text-muted-foreground">Self-reported awareness data shared by the user. Not a diagnosis; estimates are estimates.</p>
      </header>
      {q.isError && <p role="alert" className="fh-card p-6 text-sm" data-testid="share-expired">This link has expired or does not exist. Ask the person who shared it to generate a new one.</p>}
      {s && (
        <div className="space-y-5" data-testid="shared-summary">
          <p className="text-sm text-muted-foreground">Range {s.range.from} → {s.range.to} · cycle context: {s.cycle_context} · link expires {dayjs(s.expires_at).format("D MMM YYYY")}</p>
          <div className="grid grid-cols-3 gap-3">
            {[["Days logged", s.days_logged], ["Period days", s.period_days], ["Periods", s.periods.length]].map(([l, v]) => <div key={l} className="fh-card p-4"><p className="text-xs text-muted-foreground">{l}</p><p className="text-2xl font-semibold">{v}</p></div>)}
          </div>
          <section className="fh-card p-6 space-y-3 text-sm">
            <h2 className="font-display text-2xl font-semibold">Cycle estimate</h2>
            <p>{s.estimate.enabled ? `Average cycle ≈ ${s.estimate.average_cycle_length} days (range ${s.estimate.cycle_length_range.join("–")}), ${s.estimate.confidence.replace("_", " ")} confidence.` : s.estimate.reason}</p>
            {s.periods.length > 0 && <ul className="text-muted-foreground">{s.periods.map((p) => <li key={p.start}>{p.start} – {p.end} · {p.length} days</li>)}</ul>}
          </section>
          <section className="fh-card p-6 grid gap-6 sm:grid-cols-2 text-sm">
            <div><h2 className="font-display text-2xl font-semibold">Symptoms</h2><ul className="mt-2 text-muted-foreground">{s.top_symptoms.map(([n, c]) => <li key={n}>{n} · {c} days</li>)}{!s.top_symptoms.length && <li>None logged</li>}</ul></div>
            <div><h2 className="font-display text-2xl font-semibold">Medications taken</h2><ul className="mt-2 text-muted-foreground">{s.medications.map(([n, c]) => <li key={n}>{n} · {c} days</li>)}{!s.medications.length && <li>None logged</li>}</ul></div>
          </section>
          <section className="fh-card p-6 text-sm"><h2 className="font-display text-2xl font-semibold">Limitations</h2><ul className="mt-2 list-disc pl-5 text-muted-foreground">{s.limitations.map((l) => <li key={l}>{l}</li>)}</ul></section>
          <Button asChild className="rounded-full"><a href={`${API}/share/${token}/pdf`} target="_blank" rel="noopener noreferrer" data-testid="share-pdf-link"><Download size={16} aria-hidden /> Open PDF</a></Button>
        </div>
      )}
    </main>
  );
}
