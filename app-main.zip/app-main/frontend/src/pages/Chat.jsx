import { useEffect, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Plus, SendHorizontal, AlertTriangle, RotateCcw, ExternalLink, Trash2 } from "lucide-react";
import { API, api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useT } from "@/lib/i18n";

const STARTERS = {
  en: ["Why might my cycle be irregular?", "Could this be PCOS?", "What helps with cramps?", "Is spotting between periods normal?"],
  hi: ["मेरा चक्र अनियमित क्यों हो सकता है?", "क्या यह PCOS हो सकता है?", "ऐंठन में क्या मदद करता है?", "क्या पीरियड के बीच हल्के धब्बे सामान्य हैं?"],
};

export default function Chat() {
  const qc = useQueryClient();
  const { t, lang } = useT();
  const starters = STARTERS[lang] || STARTERS.en;
  const [active, setActive] = useState(null);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [failed, setFailed] = useState(null);
  const endRef = useRef(null);
  const sessQ = useQuery({ queryKey: ["chat-sessions"], queryFn: () => api.get("/chat/sessions").then((r) => r.data) });

  useEffect(() => { endRef.current?.scrollIntoView({ block: "end" }); }, [messages]);

  const selectSession = (id) => {
    setActive(id); setFailed(null);
    api.get(`/chat/sessions/${id}/messages`).then((r) => setMessages(r.data)).catch(() => toast.error("Couldn't load this conversation."));
  };
  const newSession = async () => { const { data } = await api.post("/chat/sessions", {}); qc.invalidateQueries({ queryKey: ["chat-sessions"] }); setActive(data.id); setMessages([]); setFailed(null); return data.id; };
  const removeSession = async (id) => { await api.delete(`/chat/sessions/${id}`); qc.invalidateQueries({ queryKey: ["chat-sessions"] }); if (active === id) { setActive(null); setMessages([]); } };

  const send = async (text) => {
    const content = (text ?? input).trim();
    if (!content || streaming) return;
    const sid = active || (await newSession());
    setInput(""); setFailed(null); setStreaming(true);
    setMessages((m) => [...m.filter((x) => x.id !== "pending"), { id: `u-${Date.now()}`, role: "user", content }, { id: "pending", role: "assistant", content: "", sources: [], meta: {} }]);
    try {
      const res = await fetch(`${API}/chat/sessions/${sid}/messages`, { method: "POST", credentials: "include", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ content }) });
      if (!res.ok || !res.body) throw new Error("bad response");
      const reader = res.body.getReader(); const dec = new TextDecoder(); let buf = "";
      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const parts = buf.split("\n\n"); buf = parts.pop();
        for (const p of parts) {
          if (!p.startsWith("data: ")) continue;
          const ev = JSON.parse(p.slice(6));
          setMessages((m) => m.map((msg) => msg.id !== "pending" ? msg : ev.type === "delta" ? { ...msg, content: msg.content + ev.content } : ev.type === "meta" ? { ...msg, meta: ev, sources: ev.sources } : ev.type === "done" ? { ...msg, id: ev.message_id, sources: ev.sources, error: ev.error } : msg));
        }
      }
      qc.invalidateQueries({ queryKey: ["chat-sessions"] });
    } catch {
      setFailed(content);
      setMessages((m) => m.filter((msg) => msg.id !== "pending"));
    } finally { setStreaming(false); }
  };

  return (
    <div className="mx-auto grid max-w-6xl gap-6 md:grid-cols-12">
      <aside className="md:col-span-4 lg:col-span-3 space-y-3" aria-label="Conversations">
        <Button onClick={newSession} variant="outline" className="w-full rounded-full" data-testid="chat-new-button"><Plus size={16} aria-hidden /> {t("chat.new")}</Button>
        <ul className="space-y-1">
          {(sessQ.data || []).map((s) => (
            <li key={s.id} className="flex items-center gap-1">
              <button type="button" onClick={() => selectSession(s.id)} aria-current={active === s.id ? "true" : undefined} className={`flex-1 truncate rounded-full px-4 py-2 text-left text-sm transition-colors duration-200 ${active === s.id ? "bg-primary text-primary-foreground" : "hover:bg-secondary/50"}`} data-testid={`chat-session-${s.id}`}>{s.title}</button>
              <Button variant="ghost" size="icon" className="rounded-full h-8 w-8" aria-label={`Delete conversation ${s.title}`} onClick={() => removeSession(s.id)} data-testid={`chat-delete-${s.id}`}><Trash2 size={14} /></Button>
            </li>
          ))}
        </ul>
      </aside>

      <section className="md:col-span-8 lg:col-span-9 fh-card flex min-h-[70vh] flex-col overflow-hidden" aria-label="Chat with ForHer">
        <p className="border-b border-border bg-secondary/30 px-5 py-2.5 text-xs text-muted-foreground" data-testid="chat-disclaimer">{t("chat.disclaimer")}</p>
        <div className="flex-1 space-y-5 overflow-y-auto px-5 py-6" role="log" aria-live="polite" aria-relevant="additions text" data-testid="chat-messages">
          {messages.length === 0 && (
            <div className="mx-auto max-w-md pt-8 text-center">
              <h1 className="font-display text-3xl font-semibold">{t("chat.title")}</h1>
              <p className="mt-2 text-sm text-muted-foreground">{t("chat.intro")} <span data-testid="chat-language-note">{lang === "hi" ? t("chat.langNoteHi") : t("chat.langNote")}</span></p>
              <div className="mt-6 flex flex-wrap justify-center gap-2">{starters.map((s, i) => <button key={s} type="button" className="fh-chip" aria-pressed={false} onClick={() => send(s)} data-testid={`chat-starter-${i}`}>{s}</button>)}</div>
            </div>
          )}
          {messages.map((m) => (
            <article key={m.id} className={`max-w-[85%] ${m.role === "user" ? "ml-auto" : ""}`} data-testid={`chat-message-${m.role}`} lang={m.role === "assistant" ? (m.meta?.language || lang) : undefined}>
              {m.meta?.urgent && <p role="alert" className="mb-2 flex items-start gap-2 rounded-2xl border border-accent/40 bg-accent/10 px-4 py-2 text-sm" data-testid="chat-urgent-banner"><AlertTriangle size={16} className="mt-0.5 shrink-0 text-accent" aria-hidden /> {t("chat.urgent")}</p>}
              <div className={`whitespace-pre-wrap rounded-3xl px-5 py-3.5 text-sm leading-relaxed ${m.role === "user" ? "bg-primary text-primary-foreground rounded-br-md" : "bg-secondary/30 rounded-bl-md"}`}>{m.content || (streaming ? <span className="text-muted-foreground">{t("chat.thinking")}</span> : "")}</div>
              {m.error && <p className="mt-1 text-xs text-muted-foreground" data-testid="chat-fallback-note">{t("chat.fallbackNote")}</p>}
              {m.role === "assistant" && m.sources?.length > 0 && m.content && (
                <ul className="mt-2 flex flex-wrap gap-2" aria-label={t("chat.sources")}>
                  {m.sources.map((s) => <li key={s.id}><a href={s.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-1 rounded-full border border-border px-3 py-1 text-xs text-primary hover:bg-secondary/40" data-testid={`chat-source-${s.id}`}>{s.title} <ExternalLink size={11} aria-hidden /></a></li>)}
                </ul>
              )}
            </article>
          ))}
          {failed && (
            <div role="alert" className="rounded-2xl border border-border p-4 text-sm" data-testid="chat-error">
              <p>{t("chat.failed")}</p>
              <Button size="sm" variant="outline" className="mt-2 rounded-full" onClick={() => send(failed)} data-testid="chat-retry-button"><RotateCcw size={14} aria-hidden /> {t("chat.retry")}</Button>
            </div>
          )}
          <div ref={endRef} />
        </div>
        <form onSubmit={(e) => { e.preventDefault(); send(); }} className="flex items-end gap-2 border-t border-border bg-white/80 p-4 backdrop-blur-xl">
          <label htmlFor="chat-input" className="sr-only">{t("chat.send")}</label>
          <Textarea id="chat-input" value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } }} rows={1} maxLength={2000} placeholder={t("chat.placeholder")} className="min-h-[44px] resize-none rounded-2xl" data-testid="chat-input" />
          <Button type="submit" disabled={streaming || !input.trim()} className="rounded-full" aria-label={t("chat.send")} data-testid="chat-send-button"><SendHorizontal size={18} strokeWidth={1.5} aria-hidden /></Button>
        </form>
      </section>
    </div>
  );
}
