import { useEffect, useMemo, useState } from "react";
import dayjs from "dayjs";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { BellRing, Check, PenLine } from "lucide-react";
import { api, pendingDrafts, readDraft, clearDraft } from "@/lib/api";
import { useSync } from "@/context/SyncContext";
import CalendarGrid from "@/components/CalendarGrid";
import DayLogSheet from "@/components/DayLogSheet";
import EstimateCard from "@/components/EstimateCard";
import PeriodCheckIn from "@/components/PeriodCheckIn";
import { Button } from "@/components/ui/button";
import { useT } from "@/lib/i18n";

const PERIOD_PRESET = { period: true, flow: "medium" };

export default function Dashboard() {
  const qc = useQueryClient();
  const { t, d } = useT();
  const { online, refreshPending, setStatus } = useSync();
  const [month, setMonth] = useState(dayjs());
  const [selected, setSelected] = useState(null);
  const [preset, setPreset] = useState(null);
  const from = month.startOf("month").subtract(7, "day").format("YYYY-MM-DD");
  const to = month.endOf("month").add(7, "day").format("YYYY-MM-DD");

  const logsQ = useQuery({ queryKey: ["logs", from, to], queryFn: () => api.get(`/logs?from=${from}&to=${to}`).then((r) => r.data) });
  const estQ = useQuery({ queryKey: ["estimate"], queryFn: () => api.get("/cycles/estimate").then((r) => r.data) });
  const medsQ = useQuery({ queryKey: ["medications"], queryFn: () => api.get("/medications").then((r) => r.data) });
  const remQ = useQuery({ queryKey: ["reminders-today"], queryFn: () => api.get("/reminders/today").then((r) => r.data) });

  const logsByDate = useMemo(() => Object.fromEntries((logsQ.data || []).map((l) => [l.date, l])), [logsQ.data]);

  useEffect(() => {
    if (!online) return;
    const dates = pendingDrafts();
    if (!dates.length) return;
    (async () => {
      setStatus("saving");
      for (const d of dates) {
        const draft = readDraft(d);
        if (!draft) continue;
        try {
          await api.put(`/logs/${d}`, { ...draft, base_version: null });
          clearDraft(d);
        } catch (err) {
          if (err?.response?.status !== 409) continue;
        }
      }
      refreshPending(); setStatus("synced");
      qc.invalidateQueries({ queryKey: ["logs"] }); qc.invalidateQueries({ queryKey: ["estimate"] });
    })();
  }, [online, qc, refreshPending, setStatus]);

  const onSaved = () => { qc.invalidateQueries({ queryKey: ["logs"] }); qc.invalidateQueries({ queryKey: ["estimate"] }); };
  const markDone = async (r) => {
    await api.post(`/reminders/${r.id}/done?undo=${r.done}`);
    qc.invalidateQueries({ queryKey: ["reminders-today"] });
    if (!r.done) toast.success("Marked done");
  };

  const today = dayjs().format("YYYY-MM-DD");
  const dueNow = (remQ.data || []).filter((r) => !r.done);

  return (
    <div className="mx-auto max-w-6xl space-y-8">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="fh-eyebrow">{d().format("dddd, D MMMM")}</p>
          <h1 className="mt-1 text-4xl font-semibold tracking-tight sm:text-5xl">{t("dash.title")}</h1>
        </div>
        <Button onClick={() => setSelected(today)} className="rounded-full px-6 transition-transform duration-200 hover:-translate-y-[1px]" data-testid="log-today-button"><PenLine size={16} strokeWidth={1.5} aria-hidden /> {t("dash.logToday")}</Button>
      </div>

      {logsQ.isError && <p role="alert" className="rounded-2xl bg-secondary/40 px-4 py-3 text-sm" data-testid="logs-error">{t("dash.loadError")}</p>}

      <PeriodCheckIn estimate={estQ.data} todayLog={logsByDate[today]} onLogPeriod={() => { setPreset(PERIOD_PRESET); setSelected(today); }} />

      <div className="grid gap-8 md:grid-cols-12">
        <div className="md:col-span-7 lg:col-span-8">
          <CalendarGrid month={month} onMonthChange={setMonth} logsByDate={logsByDate} estimate={estQ.data} selected={selected} onSelect={setSelected} />
        </div>
        <div className="space-y-6 md:col-span-5 lg:col-span-4">
          <EstimateCard estimate={estQ.data} />
          <section className="fh-card p-6" aria-labelledby="reminders-heading" data-testid="reminders-today">
            <p className="fh-eyebrow flex items-center gap-2"><BellRing size={14} strokeWidth={1.5} aria-hidden /> {t("dash.remindersTitle")}</p>
            <h2 id="reminders-heading" className="mt-2 font-display text-2xl font-semibold">{dueNow.length ? t("dash.toGo", { n: dueNow.length }) : t("dash.allClear")}</h2>
            <ul className="mt-3 space-y-2">
              {(remQ.data || []).map((r) => (
                <li key={r.id} className="flex items-center justify-between gap-3 rounded-2xl border border-border px-4 py-2.5 text-sm">
                  <span className={r.done ? "line-through text-muted-foreground" : ""}>{r.time} · {r.label}</span>
                  <Button size="sm" variant={r.done ? "ghost" : "outline"} className="rounded-full" onClick={() => markDone(r)} data-testid={`reminder-done-${r.id}`} aria-label={`${r.done ? t("dash.undo") : t("dash.done")}: ${r.label}`}><Check size={14} aria-hidden /> {r.done ? t("dash.undo") : t("dash.done")}</Button>
                </li>
              ))}
              {!remQ.data?.length && <li className="text-sm text-muted-foreground">{t("dash.noReminders")}</li>}
            </ul>
          </section>
        </div>
      </div>

      <DayLogSheet date={selected} existing={selected ? logsByDate[selected] : null} medications={(medsQ.data || []).filter((m) => m.active)} preset={preset} onClose={() => { setSelected(null); setPreset(null); }} onSaved={onSaved} />
    </div>
  );
}
