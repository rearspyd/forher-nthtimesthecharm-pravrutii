import { useQuery } from "@tanstack/react-query";
import { ExternalLink, Stethoscope, Phone, BookOpen } from "lucide-react";
import { api } from "@/lib/api";

export default function Resources() {
  const resQ = useQuery({ queryKey: ["resources"], queryFn: () => api.get("/chat/resources").then((r) => r.data) });
  const srcQ = useQuery({ queryKey: ["sources"], queryFn: () => api.get("/chat/sources").then((r) => r.data) });

  return (
    <div className="mx-auto max-w-5xl space-y-10">
      <div>
        <p className="fh-eyebrow">Directory & reading</p>
        <h1 className="mt-1 text-4xl font-semibold tracking-tight sm:text-5xl">Find real people and trusted reading</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground" data-testid="resources-disclaimer">{resQ.data?.disclaimer || "This directory is general referral information, not a personalised recommendation."} It is kept separate from the AI chat on purpose.</p>
      </div>
      <section aria-labelledby="dir-heading">
        <h2 id="dir-heading" className="font-display text-2xl font-semibold">Clinician directories & helplines</h2>
        <ul className="mt-4 grid gap-4 sm:grid-cols-2" data-testid="resource-list">
          {(resQ.data?.resources || []).map((r) => (
            <li key={r.id} className="fh-card flex gap-4 p-5">
              <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-secondary/50 text-primary">{r.type === "helpline" ? <Phone size={18} strokeWidth={1.5} aria-hidden /> : <Stethoscope size={18} strokeWidth={1.5} aria-hidden />}</span>
              <div>
                <p className="font-semibold">{r.name}</p>
                <p className="text-xs uppercase tracking-wider text-muted-foreground">{r.region} · {r.type}</p>
                {r.note && <p className="mt-1 text-sm text-muted-foreground">{r.note}</p>}
                {r.url && <a href={r.url} target="_blank" rel="noopener noreferrer" className="mt-2 inline-flex items-center gap-1 text-sm text-primary underline" data-testid={`resource-link-${r.id}`}>Open <ExternalLink size={12} aria-hidden /></a>}
              </div>
            </li>
          ))}
        </ul>
      </section>
      <section aria-labelledby="src-heading">
        <h2 id="src-heading" className="font-display text-2xl font-semibold">Curated educational sources <span className="text-sm font-sans font-normal text-muted-foreground">(version {srcQ.data?.version})</span></h2>
        <ul className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3" data-testid="source-list">
          {(srcQ.data?.sources || []).map((s) => (
            <li key={s.id} className="fh-card p-4">
              <a href={s.url} target="_blank" rel="noopener noreferrer" className="flex items-start gap-3 text-sm" data-testid={`source-link-${s.id}`}>
                <BookOpen size={16} strokeWidth={1.5} className="mt-0.5 shrink-0 text-primary" aria-hidden />
                <span><span className="font-semibold text-primary underline">{s.title}</span><br /><span className="text-muted-foreground">{s.org}</span></span>
              </a>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
