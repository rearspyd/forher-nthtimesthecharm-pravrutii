import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import dayjs from "dayjs";
import { toast } from "sonner";
import { api, CYCLE_CONTEXTS } from "@/lib/api";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useT } from "@/lib/i18n";

const LANGS = [{ value: "en", label: "English" }, { value: "hi", label: "हिन्दी (Hindi)" }, { value: "kn", label: "ಕನ್ನಡ — coming soon" }, { value: "ta", label: "தமிழ் — coming soon" }, { value: "ml", label: "മലയാളം — coming soon" }];
const LIVE_LANGS = ["en", "hi"];

function Section({ title, desc, children, testId }) {
  return (
    <section className="fh-card p-6 space-y-4" aria-labelledby={`${testId}-h`} data-testid={testId}>
      <div><h2 id={`${testId}-h`} className="font-display text-2xl font-semibold">{title}</h2>{desc && <p className="mt-1 text-sm text-muted-foreground">{desc}</p>}</div>
      {children}
    </section>
  );
}

export default function Settings() {
  const { user, refresh, logout } = useAuth();
  const { t } = useT();
  const qc = useQueryClient();
  const navigate = useNavigate();
  const s = user?.settings || {};
  const [pin, setPin] = useState("");
  const [pin2, setPin2] = useState("");
  const [disablePin, setDisablePin] = useState("");
  const [confirmText, setConfirmText] = useState("");
  const sessQ = useQuery({ queryKey: ["sessions"], queryFn: () => api.get("/auth/sessions").then((r) => r.data) });
  const trashQ = useQuery({ queryKey: ["trash"], queryFn: () => api.get("/trash").then((r) => r.data) });

  const updateSettings = async (patch) => {
    try { await api.put("/me/settings", patch); await refresh(); qc.invalidateQueries({ queryKey: ["estimate"] }); toast.success("Saved"); } catch { toast.error("Couldn't save setting"); }
  };
  const setLock = async (e) => {
    e.preventDefault();
    if (pin !== pin2) return toast.error("PINs don't match");
    try { await api.post("/me/lock", { pin }); sessionStorage.setItem("forher:unlocked", "1"); await refresh(); setPin(""); setPin2(""); toast.success("App lock enabled"); } catch { toast.error("PIN must be 4–8 digits"); }
  };
  const removeLock = async (e) => {
    e.preventDefault();
    try { await api.delete("/me/lock", { data: { pin: disablePin } }); await refresh(); setDisablePin(""); toast.success("App lock disabled"); } catch { toast.error("Incorrect PIN"); }
  };
  const exportData = async () => {
    try {
      const { data } = await api.get("/me/export");
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      Object.assign(document.createElement("a"), { href: url, download: `forher-export-${dayjs().format("YYYY-MM-DD")}.json` }).click();
      URL.revokeObjectURL(url); toast.success("Export downloaded");
    } catch { toast.error("Export failed"); }
  };
  const revoke = async (id) => { await api.delete(`/auth/sessions/${id}`); qc.invalidateQueries({ queryKey: ["sessions"] }); toast.success("Device signed out"); };
  const restore = async (kind, id) => { await api.post(`/trash/${kind}/${id}/restore`); qc.invalidateQueries(); toast.success("Restored"); };
  const deleteAccount = async () => { await api.delete("/me"); sessionStorage.clear(); localStorage.clear(); await logout().catch(() => {}); navigate("/"); toast.success("Your account and all data were permanently deleted."); };

  const trashCount = (trashQ.data?.logs?.length || 0) + (trashQ.data?.medications?.length || 0) + (trashQ.data?.reminders?.length || 0);

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <p className="fh-eyebrow">Settings</p>
        <h1 className="mt-1 text-4xl font-semibold tracking-tight sm:text-5xl">Your control panel</h1>
        <p className="mt-2 text-sm text-muted-foreground">Signed in as {user?.email}. Consent accepted {user?.consent ? dayjs(user.consent.at).format("D MMM YYYY") : "—"} (policy {user?.consent?.version}).</p>
      </div>

      <Section title="Cycle context" desc="Tells ForHer when estimates are unreliable or not relevant. Estimates pause automatically for pregnancy, postpartum, menopause, or when marked not applicable." testId="settings-context">
        <Label htmlFor="cycle-context">My cycle context</Label>
        <Select value={s.cycle_context} onValueChange={(v) => updateSettings({ cycle_context: v })}>
          <SelectTrigger id="cycle-context" className="rounded-xl" data-testid="cycle-context-select"><SelectValue /></SelectTrigger>
          <SelectContent>{CYCLE_CONTEXTS.map((c) => <SelectItem key={c.value} value={c.value} data-testid={`cycle-context-${c.value}`}>{c.label}</SelectItem>)}</SelectContent>
        </Select>
      </Section>

      <Section title={t("set.language")} desc={t("set.langDesc")} testId="settings-language">
        <Label htmlFor="language">{t("set.language")}</Label>
        <Select value={s.language || "en"} onValueChange={(v) => updateSettings({ language: v })}>
          <SelectTrigger id="language" className="rounded-xl" data-testid="language-select"><SelectValue /></SelectTrigger>
          <SelectContent>{LANGS.map((l) => <SelectItem key={l.value} value={l.value} disabled={!LIVE_LANGS.includes(l.value)} data-testid={`language-option-${l.value}`}>{l.label}</SelectItem>)}</SelectContent>
        </Select>
        <label className="flex items-center justify-between text-sm"><span>Reduce motion</span><Switch checked={!!s.reduced_motion} onCheckedChange={(v) => updateSettings({ reduced_motion: v })} data-testid="reduced-motion-switch" /></label>
      </Section>

      <Section title="App lock" desc="A PIN keeps ForHer hidden on shared devices. It locks after inactivity and whenever you tap Lock." testId="settings-lock">
        {s.lock_enabled ? (
          <div className="space-y-4">
            <div>
              <Label htmlFor="timeout">Lock after (minutes of inactivity)</Label>
              <Input id="timeout" type="number" min={1} max={120} defaultValue={s.lock_timeout_min} onBlur={(e) => updateSettings({ lock_timeout_min: Number(e.target.value) })} className="mt-1 w-32 rounded-xl" data-testid="lock-timeout-input" />
            </div>
            <form onSubmit={removeLock} className="flex flex-wrap items-end gap-3">
              <div><Label htmlFor="disable-pin">Enter PIN to disable</Label><Input id="disable-pin" type="password" inputMode="numeric" value={disablePin} onChange={(e) => setDisablePin(e.target.value.replace(/\D/g, ""))} className="mt-1 rounded-xl" data-testid="lock-disable-pin-input" /></div>
              <Button type="submit" variant="outline" className="rounded-full" data-testid="lock-disable-button">Disable lock</Button>
            </form>
          </div>
        ) : (
          <form onSubmit={setLock} className="flex flex-wrap items-end gap-3">
            <div><Label htmlFor="pin">New PIN (4–8 digits)</Label><Input id="pin" type="password" inputMode="numeric" minLength={4} maxLength={8} value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))} className="mt-1 rounded-xl" data-testid="lock-pin-new-input" /></div>
            <div><Label htmlFor="pin2">Repeat PIN</Label><Input id="pin2" type="password" inputMode="numeric" minLength={4} maxLength={8} value={pin2} onChange={(e) => setPin2(e.target.value.replace(/\D/g, ""))} className="mt-1 rounded-xl" data-testid="lock-pin-repeat-input" /></div>
            <Button type="submit" className="rounded-full" disabled={pin.length < 4} data-testid="lock-enable-button">Enable lock</Button>
          </form>
        )}
      </Section>

      <Section title="Devices & sessions" desc="Sign out any device you don't recognise." testId="settings-sessions">
        <ul className="space-y-2">
          {(sessQ.data || []).map((d) => (
            <li key={d.id} className="flex items-center justify-between gap-3 rounded-2xl border border-border px-4 py-2.5 text-sm" data-testid={`session-item-${d.id}`}>
              <span className="truncate">{d.current ? "This device" : d.user_agent || "Unknown device"} · last active {dayjs(d.last_seen).format("D MMM HH:mm")}</span>
              {!d.current && <Button size="sm" variant="outline" className="rounded-full" onClick={() => revoke(d.id)} data-testid={`session-revoke-${d.id}`}>Sign out</Button>}
            </li>
          ))}
        </ul>
        <Button variant="outline" className="rounded-full" onClick={async () => { await api.post("/auth/logout-all"); navigate("/"); window.location.reload(); }} data-testid="logout-all-button">Sign out of all devices</Button>
      </Section>

      <Section title="Recently deleted" desc={`Items you removed stay here for ${trashQ.data?.recovery_days || 30} days, then disappear for good.`} testId="settings-trash">
        {trashCount === 0 ? <p className="text-sm text-muted-foreground" data-testid="trash-empty">Nothing here.</p> : (
          <ul className="space-y-2 text-sm">
            {(trashQ.data?.logs || []).map((l) => <li key={l.id} className="flex items-center justify-between rounded-2xl border border-border px-4 py-2"><span>Day log · {l.date}</span><Button size="sm" variant="outline" className="rounded-full" onClick={() => restore("logs", l.id)} data-testid={`restore-log-${l.id}`}>Restore</Button></li>)}
            {(trashQ.data?.medications || []).map((m) => <li key={m.id} className="flex items-center justify-between rounded-2xl border border-border px-4 py-2"><span>Medication · {m.name}</span><Button size="sm" variant="outline" className="rounded-full" onClick={() => restore("medications", m.id)} data-testid={`restore-med-${m.id}`}>Restore</Button></li>)}
            {(trashQ.data?.reminders || []).map((r) => <li key={r.id} className="flex items-center justify-between rounded-2xl border border-border px-4 py-2"><span>Reminder · {r.label}</span><Button size="sm" variant="outline" className="rounded-full" onClick={() => restore("reminders", r.id)} data-testid={`restore-rem-${r.id}`}>Restore</Button></li>)}
          </ul>
        )}
      </Section>

      <Section title="Your data" desc="Export everything as JSON, or permanently delete your account and all records. Deletion cannot be undone." testId="settings-data">
        <div className="flex flex-wrap gap-3">
          <Button variant="outline" className="rounded-full" onClick={exportData} data-testid="export-data-button">Export my data (JSON)</Button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="outline" className="rounded-full border-destructive text-destructive hover:bg-destructive/10" data-testid="delete-account-open">Delete account permanently</Button>
            </AlertDialogTrigger>
            <AlertDialogContent className="rounded-3xl" data-testid="delete-account-dialog">
              <AlertDialogHeader>
                <AlertDialogTitle className="font-display text-2xl">Permanently delete your account?</AlertDialogTitle>
                <AlertDialogDescription className="text-left">All logs, medications, reminders, conversations, reports and sessions will be erased immediately. There is no recovery. Type <strong>DELETE</strong> to confirm.</AlertDialogDescription>
              </AlertDialogHeader>
              <Input value={confirmText} onChange={(e) => setConfirmText(e.target.value)} placeholder="DELETE" className="rounded-xl" aria-label="Type DELETE to confirm" data-testid="delete-account-confirm-input" />
              <AlertDialogFooter>
                <AlertDialogCancel className="rounded-full" data-testid="delete-account-cancel">Keep my account</AlertDialogCancel>
                <AlertDialogAction className="rounded-full bg-destructive hover:bg-destructive/90" disabled={confirmText !== "DELETE"} onClick={deleteAccount} data-testid="delete-account-confirm">Delete everything</AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </Section>
    </div>
  );
}
