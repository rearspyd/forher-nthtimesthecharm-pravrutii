import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Pill, Trash2 } from "lucide-react";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";

export default function Medications() {
  const qc = useQueryClient();
  const medsQ = useQuery({ queryKey: ["medications"], queryFn: () => api.get("/medications").then((r) => r.data) });
  const [form, setForm] = useState({ name: "", dose: "", schedule: "" });
  const refresh = () => qc.invalidateQueries({ queryKey: ["medications"] });

  const add = async (e) => {
    e.preventDefault();
    try { await api.post("/medications", { ...form, active: true }); setForm({ name: "", dose: "", schedule: "" }); refresh(); toast.success("Medication added"); }
    catch { toast.error("Couldn't add medication"); }
  };
  const toggle = async (m) => { await api.put(`/medications/${m.id}`, { name: m.name, dose: m.dose, schedule: m.schedule, active: !m.active }); refresh(); };
  const remove = async (m) => {
    if (!window.confirm(`Remove ${m.name}? You can restore it from Settings for 30 days.`)) return;
    await api.delete(`/medications/${m.id}`); refresh(); toast.success("Moved to Recently deleted");
  };

  return (
    <div className="mx-auto max-w-4xl space-y-8">
      <div>
        <p className="fh-eyebrow">Medications & supplements</p>
        <h1 className="mt-1 text-4xl font-semibold tracking-tight sm:text-5xl">What you take</h1>
        <p className="mt-2 max-w-xl text-sm text-muted-foreground">Add anything you want to track alongside your cycle. ForHer records what you tell it; it never suggests medicines or doses.</p>
      </div>
      <form onSubmit={add} className="fh-card grid gap-4 p-6 sm:grid-cols-[1fr_1fr_1fr_auto] sm:items-end" aria-label="Add medication">
        <div><Label htmlFor="med-name">Name</Label><Input id="med-name" required maxLength={120} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="mt-1 rounded-xl" data-testid="med-name-input" /></div>
        <div><Label htmlFor="med-dose">Dose (optional)</Label><Input id="med-dose" maxLength={120} value={form.dose} onChange={(e) => setForm({ ...form, dose: e.target.value })} className="mt-1 rounded-xl" placeholder="e.g. 1 tablet" data-testid="med-dose-input" /></div>
        <div><Label htmlFor="med-schedule">When (optional)</Label><Input id="med-schedule" maxLength={200} value={form.schedule} onChange={(e) => setForm({ ...form, schedule: e.target.value })} className="mt-1 rounded-xl" placeholder="e.g. mornings" data-testid="med-schedule-input" /></div>
        <Button type="submit" className="rounded-full" data-testid="med-add-button">Add</Button>
      </form>
      <ul className="space-y-3" aria-label="Your medications" data-testid="med-list">
        {(medsQ.data || []).map((m) => (
          <li key={m.id} className="fh-card flex flex-wrap items-center justify-between gap-4 p-5" data-testid={`med-item-${m.id}`}>
            <div className="flex items-center gap-3">
              <span className="grid h-10 w-10 place-items-center rounded-full bg-secondary/50 text-primary"><Pill size={18} strokeWidth={1.5} aria-hidden /></span>
              <div><p className="font-semibold">{m.name}</p><p className="text-sm text-muted-foreground">{[m.dose, m.schedule].filter(Boolean).join(" · ") || "No details"}</p></div>
            </div>
            <div className="flex items-center gap-4">
              <label className="flex items-center gap-2 text-sm"><Switch checked={m.active} onCheckedChange={() => toggle(m)} data-testid={`med-active-${m.id}`} /> {m.active ? "Active" : "Paused"}</label>
              <Button variant="ghost" size="icon" className="rounded-full text-destructive" onClick={() => remove(m)} aria-label={`Remove ${m.name}`} data-testid={`med-delete-${m.id}`}><Trash2 size={16} strokeWidth={1.5} /></Button>
            </div>
          </li>
        ))}
        {medsQ.data?.length === 0 && <li className="text-sm text-muted-foreground" data-testid="med-empty">Nothing added yet. Active medications appear as checkboxes in your daily log.</li>}
      </ul>
    </div>
  );
}
