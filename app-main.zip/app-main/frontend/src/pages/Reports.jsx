import { useState } from "react";
import dayjs from "dayjs";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Download, Link2, FileText } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { api } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import SymptomTrends from "@/components/SymptomTrends";
import CycleHistory from "@/components/CycleHistory";
import { useT } from "@/lib/i18n";

const PRESETS = [{ label: "Last 30 days", days: 30 }, { label: "Last 90 days", days: 90 }, { label: "Last 6 months", days: 182 }];

function Stat({ label, value, testId }) {
  return <div className="rounded-2xl bg-secondary/30 p-4"><p className="text-xs text-muted-foreground">{label}</p><p className="text-2xl font-semibold" data-testid={testId}>{value}</p></div>;
}

export default function Reports() {
  const qc = useQueryClient();
  const { t, tOpt } = useT();
  const [range, setRange] = useState({ from: dayjs().subtract(90, "day").format("YYYY-MM-DD"), to: dayjs().format("YYYY-MM-DD") });
  const [mode, setMode] = useState("personal");
  const [busy, setBusy] = useState(false);
  const sumQ = useQuery({ queryKey: ["summary", range.from, range.to, mode], queryFn: () => api.get(`/reports/summary?from=${range.from}&to=${range.to}&mode=${mode}`).then((r) => r.data), enabled: range.from <= range.to });
  const repQ = useQuery({ queryKey: ["reports"], queryFn: () => api.get("/reports").then((r) => r.data) });
  const s = sumQ.data;

  const generate = async () => {
    setBusy(true);
    try { await api.post("/reports/pdf", { from: range.from, to: range.to, mode }); qc.invalidateQueries({ queryKey: ["reports"] }); toast.success("PDF ready below"); }
    catch { toast.error("Couldn't generate the PDF right now."); } finally { setBusy(false); }
  };
  const download = async (r) => {
    try {
      const res = await api.get(`/reports/${r.id}/download`, { responseType: "blob" });
      const url = URL.createObjectURL(res.data);
      const a = Object.assign(document.createElement("a"), { href: url, download: `forher-${r.mode}-${r.from}-to-${r.to}.pdf` });
      a.click(); URL.revokeObjectURL(url);
    } catch { toast.error("Download failed."); }
  };
  const share = async (r) => {
    try {
      const { data } = await api.post(`/reports/${r.id}/share`);
      const link = `${window.location.origin}/share/${data.token}`;
      await navigator.clipboard?.writeText(link);
      toast.success(`Secure link copied. It expires ${dayjs(data.expires_at).format("D MMM")}. Only the clinician summary is shared — no personal notes beyond the first few.`, { duration: 8000 });
    } catch { toast.error("Couldn't create a share link."); }
  };

  return (
    <div className="mx-auto max-w-5xl space-y-8">
      <div>
        <p className="fh-eyebrow">{t("rep.eyebrow")}</p>
        <h1 className="mt-1 text-4xl font-semibold tracking-tight sm:text-5xl">{t("rep.title")}</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">Self-reported data only. Estimates are estimates. A report is a conversation starter for you or your clinician — not a diagnosis.</p>
      </div>

      <section className="fh-card space-y-5 p-6" aria-label="Report settings">
        <div className="flex flex-wrap items-end gap-4">
          <div><Label htmlFor="from">From</Label><Input id="from" type="date" value={range.from} max={range.to} onChange={(e) => setRange({ ...range, from: e.target.value })} className="mt-1 rounded-xl" data-testid="report-from-input" /></div>
          <div><Label htmlFor="to">To</Label><Input id="to" type="date" value={range.to} min={range.from} onChange={(e) => setRange({ ...range, to: e.target.value })} className="mt-1 rounded-xl" data-testid="report-to-input" /></div>
          <div className="flex flex-wrap gap-2">
            {PRESETS.map((p) => <button key={p.days} type="button" className="fh-chip" aria-pressed={false} onClick={() => setRange({ from: dayjs().subtract(p.days, "day").format("YYYY-MM-DD"), to: dayjs().format("YYYY-MM-DD") })} data-testid={`report-preset-${p.days}`}>{p.label}</button>)}
          </div>
        </div>
        <Tabs value={mode} onValueChange={setMode}>
          <TabsList className="rounded-full bg-secondary/40">
            <TabsTrigger value="personal" className="rounded-full" data-testid="report-mode-personal">Personal view</TabsTrigger>
            <TabsTrigger value="doctor" className="rounded-full" data-testid="report-mode-doctor">Clinician summary</TabsTrigger>
          </TabsList>
        </Tabs>
        {mode === "doctor" && <p className="text-xs text-muted-foreground" data-testid="doctor-mode-note">Clinician summary keeps your name off the PDF, limits notes, and leads with cycle data, symptoms and medications.</p>}
      </section>

      {sumQ.isError && <p role="alert" className="rounded-2xl bg-secondary/40 px-4 py-3 text-sm">Couldn't load this summary. Check the range or try again.</p>}
      {s && (
        <section className="space-y-6" aria-live="polite" data-testid="report-summary">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat label="Days logged" value={s.days_logged} testId="stat-days-logged" />
            <Stat label="Period days" value={s.period_days} testId="stat-period-days" />
            <Stat label="Periods in range" value={s.periods.length} testId="stat-periods" />
            <Stat label="Avg cycle (est.)" value={s.estimate.enabled ? `${s.estimate.average_cycle_length} d` : "—"} testId="stat-avg-cycle" />
          </div>
          <div className="grid gap-6 md:grid-cols-2">
            <div className="fh-card p-6">
              <h2 className="font-display text-2xl font-semibold">Most logged symptoms</h2>
              {s.top_symptoms.length ? (
                <div className="mt-4 h-56" role="img" aria-label={`Symptom frequency: ${s.top_symptoms.map(([n, c]) => `${n} ${c} days`).join(", ")}`}>
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={s.top_symptoms.slice(0, 6).map(([name, count]) => ({ name, count }))} layout="vertical" margin={{ left: 8, right: 16 }}>
                      <XAxis type="number" allowDecimals={false} hide /><YAxis type="category" dataKey="name" width={110} tick={{ fontSize: 12, fill: "#5C4B4D" }} />
                      <Tooltip cursor={{ fill: "rgba(160,90,101,0.08)" }} /><Bar dataKey="count" fill="#A05A65" radius={[0, 8, 8, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              ) : <p className="mt-3 text-sm text-muted-foreground">No symptoms logged in this range.</p>}
            </div>
            <div className="fh-card p-6 space-y-4">
              <h2 className="font-display text-2xl font-semibold">Cycle estimate</h2>
              <p className="text-sm leading-relaxed">{s.estimate.enabled ? `Average cycle ≈ ${s.estimate.average_cycle_length} days (range ${s.estimate.cycle_length_range.join("–")}), ${s.estimate.confidence.replace("_", " ")} confidence. ${s.estimate.confidence_note}` : s.estimate.reason}</p>
              {s.periods.length > 0 && <ul className="text-sm text-muted-foreground">{s.periods.map((p) => <li key={p.start}>{dayjs(p.start).format("D MMM")} – {dayjs(p.end).format("D MMM")} · {p.length} days</li>)}</ul>}
              {s.medications.length > 0 && <div><h3 className="font-semibold">Medications marked taken</h3><ul className="text-sm text-muted-foreground">{s.medications.map(([n, c]) => <li key={n}>{n} · {c} days</li>)}</ul></div>}
              {s.top_moods.length > 0 && <div><h3 className="font-semibold">Moods</h3><p className="text-sm text-muted-foreground">{s.top_moods.map(([n, c]) => `${n} (${c})`).join(", ")}</p></div>}
            </div>
          </div>
          <SymptomTrends trends={s.symptom_trends} title={t("rep.symptomTrends")} labelOf={tOpt} />
          <SymptomTrends trends={s.mood_trends} title={t("rep.moodTrends")} testId="mood-trends" labelOf={tOpt} />
          <CycleHistory />
          <div className="fh-card p-6">
            <h2 className="font-display text-2xl font-semibold">Limitations</h2>
            <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-muted-foreground">{s.limitations.map((l) => <li key={l}>{l}</li>)}</ul>
          </div>
          <Button onClick={generate} disabled={busy} className="rounded-full px-6" data-testid="generate-pdf-button"><FileText size={16} strokeWidth={1.5} aria-hidden /> {busy ? "Preparing PDF…" : `Create ${mode === "doctor" ? "clinician" : "personal"} PDF`}</Button>
        </section>
      )}

      <section aria-labelledby="generated-heading" className="space-y-3">
        <h2 id="generated-heading" className="font-display text-2xl font-semibold">Generated PDFs</h2>
        <ul className="space-y-2" data-testid="report-list">
          {(repQ.data || []).map((r) => (
            <li key={r.id} className="fh-card flex flex-wrap items-center justify-between gap-3 p-4" data-testid={`report-item-${r.id}`}>
              <div className="text-sm"><p className="font-semibold">{r.mode === "doctor" ? "Clinician summary" : "Personal report"} · {r.from} → {r.to}</p><p className="text-muted-foreground">Created {dayjs(r.created_at).format("D MMM, HH:mm")}{r.share_expires_at ? ` · shared until ${dayjs(r.share_expires_at).format("D MMM")}` : ""}</p></div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="rounded-full" onClick={() => download(r)} data-testid={`report-download-${r.id}`}><Download size={14} aria-hidden /> Download</Button>
                <Button variant="outline" size="sm" className="rounded-full" onClick={() => share(r)} data-testid={`report-share-${r.id}`}><Link2 size={14} aria-hidden /> Share link (7 days)</Button>
              </div>
            </li>
          ))}
          {repQ.data?.length === 0 && <li className="text-sm text-muted-foreground">No PDFs yet.</li>}
        </ul>
      </section>
    </div>
  );
}
