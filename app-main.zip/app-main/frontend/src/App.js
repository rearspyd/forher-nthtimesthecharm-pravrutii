import { useEffect, useRef, useState } from "react";
import "@/App.css";
import { BrowserRouter, Routes, Route, useLocation, useNavigate, Navigate, Outlet } from "react-router-dom";
import { Toaster } from "@/components/ui/sonner";
import { api } from "@/lib/api";
import { AuthProvider, useAuth } from "@/context/AuthContext";
import { SyncProvider } from "@/context/SyncContext";
import AppShell from "@/components/AppShell";
import Landing from "@/pages/Landing";
import Dashboard from "@/pages/Dashboard";
import Medications from "@/pages/Medications";
import Reminders from "@/pages/Reminders";
import Reports from "@/pages/Reports";
import Chat from "@/pages/Chat";
import Resources from "@/pages/Resources";
import Settings from "@/pages/Settings";
import SharedReport from "@/pages/SharedReport";

function AuthCallback() {
  const processed = useRef(false);
  const navigate = useNavigate();
  const { setUser } = useAuth();
  const [error, setError] = useState(null);

  useEffect(() => {
    if (processed.current) return;
    processed.current = true;
    const sessionId = new URLSearchParams(window.location.hash.replace(/^#/, "")).get("session_id");
    window.history.replaceState(null, "", window.location.pathname);
    api.post("/auth/session", { session_id: sessionId })
      .then(({ data }) => { setUser(data); navigate("/app", { replace: true, state: { user: data } }); })
      .catch(() => setError("We couldn't complete sign-in. Please try again."));
  }, [navigate, setUser]);

  return (
    <main className="min-h-screen grid place-items-center p-6" aria-live="polite">
      {error ? (
        <div className="fh-card p-8 max-w-md" data-testid="auth-error">
          <p className="text-base">{error}</p>
          <a href="/" className="mt-4 inline-block text-primary underline">Back to start</a>
        </div>
      ) : <p className="text-muted-foreground" data-testid="auth-processing">Signing you in…</p>}
    </main>
  );
}

function Protected() {
  const { user, loading } = useAuth();
  if (loading) return <main className="min-h-screen grid place-items-center text-muted-foreground" aria-busy="true">Loading ForHer…</main>;
  if (!user) return <Navigate to="/" replace />;
  return <Outlet />;
}

function AppRouter() {
  const location = useLocation();
  if (location.hash?.includes("session_id=")) return <AuthCallback />;
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/share/:token" element={<SharedReport />} />
      <Route element={<Protected />}>
        <Route path="/app" element={<AppShell />}>
          <Route index element={<Dashboard />} />
          <Route path="medications" element={<Medications />} />
          <Route path="reminders" element={<Reminders />} />
          <Route path="reports" element={<Reports />} />
          <Route path="chat" element={<Chat />} />
          <Route path="resources" element={<Resources />} />
          <Route path="settings" element={<Settings />} />
        </Route>
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <AuthProvider>
          <SyncProvider>
            <AppRouter />
            <Toaster position="top-center" richColors closeButton />
          </SyncProvider>
        </AuthProvider>
      </BrowserRouter>
    </div>
  );
}
